------------------------------------------------------------------------------------------
Gerber File Extension Report For: led30.GBR   3/6/2016  4:32:55 PM
------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------
Layer Extension     Layer Description                      
------------------------------------------------------------------------------------------
.GTL                Top Layer                               
.GBL                Bottom Layer                            
.GPB                Bottom Pad Master                       
.GPT                Top Pad Master                          
.GTO                Top Overlay                             
.GTP                Top Paste                               
.GTS                Top Solder                              
.GBS                Bottom Solder                           
.GBP                Bottom Paste                            
.GBO                Bottom Overlay                          
.GKO                Keep-Out Layer                          
.GM13               Mechanical 13                           
.GM15               Mechanical 15                           
------------------------------------------------------------------------------------------
